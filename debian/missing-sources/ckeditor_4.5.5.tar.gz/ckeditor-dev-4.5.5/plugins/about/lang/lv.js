﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'lv', {
	copy: 'Kopēšanas tiesības &copy; $1. Visas tiesības rezervētas.',
	dlgTitle: 'Par CKEditor',
	help: 'Pārbaudiet $1 palīdzībai.',
	moreInfo: 'Informācijai par licenzēšanu apmeklējiet mūsu mājas lapu:',
	title: 'Par CKEditor',
	userGuide: 'CKEditor Lietotāja pamācība'
} );
