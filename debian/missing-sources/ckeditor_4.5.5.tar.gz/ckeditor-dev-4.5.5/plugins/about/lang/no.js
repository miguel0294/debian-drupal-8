﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'no', {
	copy: 'Copyright &copy; $1. Alle rettigheter reservert.',
	dlgTitle: 'Om CKEditor',
	help: 'Se $1 for hjelp.',
	moreInfo: 'For lisensieringsinformasjon, vennligst besøk vårt nettsted:',
	title: 'Om CKEditor',
	userGuide: 'CKEditors brukerveiledning'
} );
