/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'ko', {
	bold: '굵게',
	italic: '기울임꼴',
	strike: '취소선',
	subscript: '아래 첨자',
	superscript: '위 첨자',
	underline: '밑줄'
} );
